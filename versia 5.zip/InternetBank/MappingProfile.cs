﻿internal class MappingProfile
{
}