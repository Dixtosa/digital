﻿using Core.Services;
using InternetBank.Models;
using Microsoft.AspNetCore.Mvc;

namespace InternetBank.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoanController : ControllerBase
    {
        private readonly ILoanService _loanService;

        public LoanController(ILoanService loanService)
        {
            _loanService = loanService;
        }

        /// <summary>
        /// სესხის დაფარვა
        /// </summary>
        /// <returns></returns>
        [HttpPost("CollectDueLoans")]
        public async Task<IActionResult> CollectDueLoans()
        {
            var result = await _loanService.CollectDueLoans();

            if (!result.Success)
                return BadRequest(result.Message);

            return Ok(result.Message);
        }

        /// <summary>
        /// სესხის აღება
        /// </summary>
        /// <returns></returns>
        [HttpPost("Loans")]
        public async Task<IActionResult> RegisterLoan(CreateLoanDto request)
        {
            var loanId = await _loanService.RegisterLoan(request);
            
            return Ok();
        }
    }
}
