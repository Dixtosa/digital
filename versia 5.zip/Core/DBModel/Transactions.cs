﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.DBModel
{
    public class Transactions
    {
        public Guid Id { get; set; }
        public DateTime Date { get; set; }
        public Guid SenderAccountId { get; set; }
        public Guid ReceiverAccountId { get; set; }
        public decimal Amount { get; set; }
        public Guid CurrencyId { get; set; }
        public string Description { get; set; } = null!;
        [Column("ReceiverAccount")]
        public string ReceiverAccountName { get; set; }

        public BankAccount SenderAccount { get; set; } = null!;
        public BankAccount ReceiverAccount { get; set; } = null!;
        public Currency Currency { get; set; } = null!;
    }
}