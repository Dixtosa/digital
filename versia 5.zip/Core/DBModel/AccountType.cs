﻿using InternetBank.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.DBModel
{
    public class AccountType
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = null!;

        public ICollection<BankAccount> BankAccounts { get; set; } = new List<BankAccount>();

        public static Guid CheckingAccountType = Guid.Parse("40016949-0AD2-457F-88C3-428C85779D69");
        public static Guid LoanAccountType = Guid.Parse("6841EFA0-EE6B-4047-9259-579CF3C85C36");
    }
}
