﻿using InternetBank.Models;

namespace Core.Services
{
    public interface IBankAccountService
    {
        Task<IEnumerable<BankAccountDto>> GetAllAsync();
        Task<BankAccountDto?> GetByIdAsync(Guid id);
        Task<BankAccountDto> CreateAsync(CreateBankAccountDto dto);
        Task<bool> UpdateAsync(Guid id, CreateBankAccountDto dto);
        Task<bool> DeleteAsync(Guid id);
        Task<List<BankAccountDto>> GetBySearchText(string searchText);
    }
}
