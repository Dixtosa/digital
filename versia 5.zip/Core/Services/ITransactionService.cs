﻿using InternetBank.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Services
{
    public interface ITransactionService
    {
        Task<TransactionReportResponseDto> GetTransactionReportAsync(TransactionReportRequestDto request);
        Task<Guid> Transfer(TransferDto request);
    }
}
