﻿namespace Core.Services
{
    public interface ICurrencyRateService
    {
        decimal Convert(decimal value, Guid fromCurrency, Guid toCurrency);
    }
}
