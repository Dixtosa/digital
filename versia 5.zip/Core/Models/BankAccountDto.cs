﻿using Core.DBModel;

namespace InternetBank.Models
{
    public class BankAccountDto
    {
        public BankAccountDto()
        {
            
        }

        public BankAccountDto(BankAccount dbModel)
        {
            this.Id = dbModel.Id;
            this.AccountNumber = dbModel.AccountNumber;
            this.AccountTypeId = dbModel.AccountTypeId;
            this.Amount = dbModel.Amount;
            this.CurrencyId = dbModel.CurrencyId;
            this.UserId = dbModel.UserId;
        }
        public Guid Id { get; set; }
        public string AccountNumber { get; set; } = null!;
        public Guid AccountTypeId { get; set; }
        public decimal Amount { get; set; }
        public Guid CurrencyId { get; set; }
        public Guid UserId { get; set; }
    }
}
