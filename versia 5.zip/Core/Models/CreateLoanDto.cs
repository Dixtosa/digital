﻿namespace InternetBank.Models
{
    public class CreateLoanDto
    {
        public Guid UserId { get; set; }
        public DateTime DateFrom { get; set; }
        public DateTime DateTill { get; set; }
        public decimal LoanAmount { get; set; }
        public decimal MonthlyPaymentAmount { get; set; }
        public DateTime LoanDate { get; set; }
    }
}
