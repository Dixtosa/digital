﻿namespace InternetBank.Models
{
    public class TransferDto
    {
        public Guid SenderAccountId { get; set; }
        public Guid ReceiverAccountId { get; set; }
        public decimal Amount { get; set; }
        public string Description { get; set; } = null!;
    }
}
