﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.DBModel;
using InternetBank.Models;

namespace Core.Interfaces.Repositories
{
    public interface ITransactionRepository
    {
        Task<List<Transactions>> GetByUserIdsAndDateRangeAsync(Guid userId, DateTime from, DateTime to);
        Task<List<Transactions>> GetByAccountIdsAndDateRangeAsync(Guid accountId, DateTime from, DateTime to);
        Task<Guid> CreateTransfer(decimal sendingAmount, decimal receivingAmount, Transactions request);
    }
}
