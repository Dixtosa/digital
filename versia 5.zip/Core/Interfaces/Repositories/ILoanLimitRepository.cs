﻿using Core.DBModel;
using InternetBank.Models;

namespace Core.Interfaces.Repositories
{
    public interface ILoanLimitRepository
    {
        Task<bool> CreateAsync(CreateLoanLimitDto dto);
        Task<LoanLimits?> GetLoanLimit(Guid userId);
    }
}
