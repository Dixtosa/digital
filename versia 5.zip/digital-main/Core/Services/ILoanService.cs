﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Services
{
    public interface ILoanService
    {
        Task<(bool Success, string Message)> ProcessDuePaymentsAsync();
    }
}
