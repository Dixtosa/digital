﻿using InternetBank.Models;
using Microsoft.EntityFrameworkCore;
using Core.Interfaces.Repositories;
using Core.DBModel;

namespace Infrastructure.Repositories
{
    public class TransactionRepository : ITransactionRepository
    {
        private readonly InternetBankDbContext  context;

        public TransactionRepository(InternetBankDbContext context)
        {
            this.context = context;
        }

        public async Task<Guid> CreateTransfer(decimal sendingAmount, decimal receivingAmount, Transactions request)
        {
            var senderAccount = await this.context.BankAccounts.FindAsync(request.SenderAccountId);
            var receiverAccount = await this.context.BankAccounts.FindAsync(request.ReceiverAccountId);

            senderAccount.Amount -= sendingAmount;
            receiverAccount.Amount += receivingAmount;

            this.context.Add(request);

            await this.context.SaveChangesAsync();

            return request.Id;
        }

        public async Task<List<Core.DBModel.Transactions>> GetByAccountIdsAndDateRangeAsync(
            Guid accountId, DateTime from, DateTime to)
        {
            return await context.Transactions
                .Include(t => t.SenderAccount)
                .Include(t => t.ReceiverAccount)
                .Include(t => t.Currency)
                .Where(t =>
                    ((t.SenderAccountId == accountId) || (t.ReceiverAccountId == accountId)) &&
                    t.Date >= from && t.Date <= to)
                .ToListAsync();
        }

        public async Task<List<Core.DBModel.Transactions>> GetByUserIdsAndDateRangeAsync(
            Guid userId, DateTime from, DateTime to)
        {
            return await context.Transactions
                .Include(t => t.SenderAccount)
                .Include(t => t.ReceiverAccount)
                .Include(t => t.Currency)
                .Where(t =>
                    (t.SenderAccount.UserId == userId) &&
                    t.Date >= from && t.Date <= to)
                .ToListAsync();
        }
    }
}

