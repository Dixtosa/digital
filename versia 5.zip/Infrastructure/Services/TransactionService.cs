﻿using InternetBank.Models;
using Core.Services;
using Core.Interfaces.Repositories;
using Core;
using Core.DBModel;


namespace Infrastructure.Services
{
    public class TransactionService : ITransactionService
    {
        private readonly ITransactionRepository transactionRepository;
        private readonly IBankAccountRepository accountRepository;
        private readonly ICurrencyRateService currencyRateService;

        public TransactionService(
            ITransactionRepository transactionRepository,
            IBankAccountRepository accountRepository,
            ICurrencyRateService currencyRateService
            )
        {
            this.transactionRepository = transactionRepository;
            this.accountRepository = accountRepository;
            this.currencyRateService = currencyRateService;
        }

        public async Task<TransactionReportResponseDto> GetTransactionReportAsync(TransactionReportRequestDto request)
        {
            List<Core.DBModel.Transactions> transactions;

            if (request.UserId.HasValue)
            {
                transactions = await transactionRepository.GetByUserIdsAndDateRangeAsync(
                    request.UserId.Value, request.FromDate, request.ToDate);
            }
            else if (request.AccountId.HasValue)
            {
                transactions = await transactionRepository.GetByAccountIdsAndDateRangeAsync(
                    request.AccountId.Value, request.FromDate, request.ToDate);
            }
            else
            {
                throw new InternetBankException("არასწორი პარამეტრები");
            }

            decimal income = 0, outcome = 0;
            if (request.UserId.HasValue)
            {
                income = transactions
                    .Where(t => t.SenderAccount.UserId != request.UserId)
                    .Sum(t => t.Amount);
                outcome = transactions
                    .Where(t => t.SenderAccount.UserId == request.UserId)
                    .Sum(t => t.Amount);
            }
            else if (request.AccountId.HasValue)
            {
                income = transactions
                    .Where(t => t.SenderAccountId != request.AccountId)
                    .Sum(t => t.Amount);
                outcome = transactions
                    .Where(t => t.SenderAccountId == request.AccountId)
                    .Sum(t => t.Amount);
            }

            return new TransactionReportResponseDto
            {
                Transactions = transactions.Select(t => new TransactionDto
                {
                    Amount = t.Amount,
                    Currency = t.Currency?.Name,
                    Date = t.Date,
                    Description = t.Description,
                    Id = t.Id.ToString(),
                    ReceiverAccount = t.ReceiverAccount.AccountNumber,
                    SenderAccount = t.SenderAccount.AccountNumber
                }).ToList(),
                TotalIncome = income,
                TotalOutcome = outcome
            };
        }

        public async Task<Guid> Transfer(TransferDto request)
        {
            var senderAccount = await this.accountRepository.GetByIdAsync(request.SenderAccountId);
            var receiverAccount = await this.accountRepository.GetByIdAsync(request.ReceiverAccountId);
            var receivingAmount = request.Amount;

            if (senderAccount is null || receiverAccount is null)
                throw new InternetBankException("არასწორი პარამეტრები");

            if (request.Amount > senderAccount.Amount)
                throw new InternetBankException("არასაკმარისი ნაშთი");

            if (senderAccount.CurrencyId != receiverAccount.CurrencyId)
            {
                receivingAmount = (currencyRateService.Convert(receivingAmount, senderAccount.CurrencyId, receiverAccount.CurrencyId));
            }

            return await this.transactionRepository.CreateTransfer(
                request.Amount, 
                receivingAmount,
                new Transactions
            {
                Id = Guid.NewGuid(),
                Date = DateTime.UtcNow,
                ReceiverAccountId = request.ReceiverAccountId,
                ReceiverAccountName = receiverAccount.AccountNumber,
                Amount = receivingAmount,
                SenderAccountId = request.SenderAccountId,
                CurrencyId = receiverAccount.CurrencyId,
                Description = request.Description
            });
        }
    }
}
