﻿using Core.Services;
using InternetBank.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
    public class CurrencyRateService : ICurrencyRateService
    {
        private InternetBankDbContext context;

        public CurrencyRateService(InternetBankDbContext context)
        {
            this.context = context;
        }

        /// <summary>
        /// 100USD -> GEL
        /// </summary>
        /// <param name="value"></param>
        /// <param name="fromCurrencyId"></param>
        /// <param name="toCurrencyId"></param>
        /// <returns></returns>
        public decimal Convert(decimal value, Guid fromCurrencyId, Guid toCurrencyId)
        {
            decimal amount = value;
            var fromCurrency = context.Currencies.Find(fromCurrencyId);
            var toCurrency = context.Currencies.Find(toCurrencyId);

            if (fromCurrency.Code != "GEL")
            {
                var rate = context.CurrencyRates.Where(cr => cr.CurrencyId == fromCurrencyId)
                    .OrderBy(cr => cr.Date).Last();

                amount *= rate.Rate;
            }

            if (toCurrency.Code != "GEL")
            {
                var rate = context.CurrencyRates.Where(cr => cr.CurrencyId == toCurrencyId)
                    .OrderBy(cr => cr.Date).Last();

                amount /= rate.Rate;
            }

            return amount;
        }
    }
}
