﻿using Core.DBModel;
using Core.Services;
using InternetBank.Models;
using Microsoft.EntityFrameworkCore;
using Core.Interfaces.Repositories;
using Core;

namespace Infrastructure.Services
{
    public class LoanService : ILoanService
    {
        private readonly InternetBankDbContext context;
        private readonly IBankAccountService bankAccountService;
        private readonly ICurrencyRepository currencyRepository;
        private readonly ILoanLimitRepository loanLimitRepository;

        public LoanService(InternetBankDbContext context,
            IBankAccountService bankAccountService,
            ICurrencyRepository currencyRepository,
            ILoanLimitRepository loanLimitRepository
            )
        {
            this.context = context;
            this.bankAccountService = bankAccountService;
            this.currencyRepository = currencyRepository;
            this.loanLimitRepository = loanLimitRepository;
        }

        public async Task<Guid> RegisterLoan(CreateLoanDto request)
        {
            var limit = await this.loanLimitRepository.GetLoanLimit(request.UserId);
            if (limit is null)
                throw new InternetBankException("კლიენტს არ აქვს დამტკიცებული ლიმიტი");
            if (request.LoanAmount > limit.Amount)
                throw new InternetBankException("მოთხოვნილი თანხა აღემატება თქვენს ლიმიტს");

            var gel = (await this.currencyRepository.GetByCodeAsync("GEL"))!.Id;
            var loanId = Guid.NewGuid();
            var account = await this.bankAccountService.CreateAsync(new CreateBankAccountDto
            {
                AccountNumber = "LoanAcc_" + loanId,
                AccountTypeId = AccountType.LoanAccountType,
                Amount = request.LoanAmount,
                CurrencyId = gel,
                UserId = request.UserId
            });

            this.context.Loans.Add(new Loans
            {
                BankAccountId = account.Id,
                LoanAmount = request.LoanAmount,
                UserId = request.UserId,
                DateFrom = request.DateFrom,
                DateTill = request.DateTill,
                Id = loanId,
                LoanDate = request.LoanDate,
                LoanRemainigAmount = request.LoanAmount,
                MonthlyPaymentAmount = request.MonthlyPaymentAmount,
            });
            await this.context.SaveChangesAsync();

            return loanId;
        }

        public async Task<(bool Success, string Message)> CollectDueLoans()
        {
            var dueLoans = await context.Loans
                .Include(l => l.BankAccount)
                .Where(l => l.LoanDate.Date <= DateTime.Today && l.LoanRemainigAmount > 0)
                .ToListAsync();
            var gel = (await this.currencyRepository.GetByCodeAsync("GEL"))!.Id;

            int processed = 0;

            foreach (var loan in dueLoans)
            {
                var mainAccount = loan.BankAccount;
                decimal required = loan.MonthlyPaymentAmount;
                decimal collected = 0;

                var deductions = new List<(BankAccount account, decimal amount)>();

                var firstPortion = Math.Min(required, mainAccount.Amount);
                if (firstPortion > 0)
                {
                    collected += firstPortion;
                    deductions.Add((mainAccount, firstPortion));
                }

                if (collected < required)
                {
                    var otherAccounts = await context.BankAccounts
                        .Where(a => a.UserId == loan.UserId && a.Id != mainAccount.Id && a.Amount > 0)
                        .OrderByDescending(a => a.Amount)
                        .ToListAsync();

                    foreach (var acc in otherAccounts)
                    {
                        var portion = Math.Min(required - collected, acc.Amount);
                        if (portion > 0)
                        {
                            collected += portion;
                            deductions.Add((acc, portion));
                        }

                        if (collected >= required)
                            break;
                    }
                }

                if (collected < required)
                {
                    continue;
                }

                foreach (var deduction in deductions)
                {
                    CreateTransaction(deduction.account, loan.BankAccount, deduction.amount, gel);
                }

                loan.LoanRemainigAmount -= collected;

                loan.LoanDate = loan.LoanDate.AddMonths(1);

                await context.SaveChangesAsync();
                
                processed++;
            }

            return (true, $"დამუშავდა {processed} აქტიური სესხი");
        }

        private void CreateTransaction(BankAccount account, BankAccount loanAccount, decimal amount, Guid currencyId)
        {
            account.Amount -= amount;
            var transaction = new Transactions
            {
                Date = DateTime.UtcNow,
                SenderAccountId = account.Id,
                ReceiverAccountId = loanAccount.Id,
                Amount = amount,
                CurrencyId = currencyId,
                ReceiverAccountName = loanAccount.AccountNumber,
                Description = "ავტომატური სესხის გადახდა"
            };
            context.Transactions.Add(transaction);
        }
    }

}